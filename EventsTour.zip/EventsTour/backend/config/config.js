require('dotenv').config();

module.exports = {
    port: process.env.PORT || 3000,
    razorpay: {
        keyId: process.env.RAZORPAY_KEY_ID,
        keySecret: process.env.RAZORPAY_KEY_SECRET
    }
};