const express = require('express');
const Razorpay = require('razorpay');
const crypto = require('crypto');
const router = express.Router();
const config = require('../config/config');
const eventModel = require('../models/event');

// Initialize Razorpay
const razorpay = new Razorpay({
    key_id: config.razorpay.keyId,
    key_secret: config.razorpay.keySecret
});

// Create a payment order
router.post('/create-order', async (req, res) => {
    const { eventName, amount } = req.body;

    const options = {
        amount: amount * 100, // Convert INR to paise
        currency: 'INR',
        receipt: `receipt_${Date.now()}`
    };

    try {
        const order = await razorpay.orders.create(options);
        res.json({
            orderId: order.id,
            amount: order.amount,
            currency: order.currency,
            eventName
        });
    } catch (error) {
        console.error('Error creating order:', error);
        res.status(500).json({ error: 'Failed to create payment order' });
    }
});

// Verify payment and register event
router.post('/verify-payment', (req, res) => {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, eventName } = req.body;

    const body = razorpay_order_id + '|' + razorpay_payment_id;
    const expectedSignature = crypto
        .createHmac('sha256', config.razorpay.keySecret)
        .update(body.toString())
        .digest('hex');

    if (expectedSignature === razorpay_signature) {
        // Payment verified, register the event
        const success = eventModel.registerEvent(eventName);
        if (success) {
            console.log('Registered event:', eventName);
            res.json({ status: 'success', eventName });
        } else {
            res.json({ status: 'already_registered', eventName });
        }
    } else {
        console.error('Payment verification failed');
        res.status(400).json({ status: 'failure', message: 'Invalid signature' });
    }
});

// Get registered events
router.get('/registered-events', (req, res) => {
    const events = eventModel.getRegisteredEvents();
    res.json(events);
});

module.exports = router;