// In-memory storage for registered events
let registeredEvents = [];

// Simulated student ID (replace with real auth in production)
const studentId = 'student123'; // Hardcoded for now

module.exports = {
    getRegisteredEvents: () => registeredEvents,
    registerEvent: (eventName) => {
        if (!registeredEvents.includes(eventName)) {
            registeredEvents.push(eventName);
            return true;
        }
        return false;
    },
    // For future use: tie events to specific students
    getEventsForStudent: (id) => {
        return id === studentId ? registeredEvents : [];
    }
};