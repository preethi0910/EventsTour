const express = require('express');
const bodyParser = require('body-parser');
const config = require('./config/config');
const apiRoutes = require('./routes/api');

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('../public')); // Serve frontend files from 'public'

// Routes
app.use('/api', apiRoutes);

// Start server
app.listen(config.port, () => {
    console.log(`Server running at http://localhost:${config.port}`);
});