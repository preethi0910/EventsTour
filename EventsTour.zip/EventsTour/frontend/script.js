// Preloader
window.addEventListener("load", () => {
    const preloader = document.getElementById("preloader");
    if (preloader) {
        preloader.style.display = "none";
        console.log("Preloader hidden");
    } else {
        console.error("Preloader not found");
    }
});

// Hamburger Menu
document.querySelector(".hamburger")?.addEventListener("click", () => {
    document.querySelector(".nav-links").classList.toggle("active");
});

// Active Navigation
const currentPage = window.location.pathname.split("/").pop() || "index.html";
document.querySelectorAll(".nav-links a").forEach(link => {
    if (link.getAttribute("href") === currentPage) {
        link.classList.add("active");
    }
});

// Smooth Scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute("href")).scrollIntoView({ behavior: "smooth" });
    });
});

// Scroll Animation
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("show");
        }
    });
}, { threshold: 0.2 });
document.querySelectorAll(".fade-in").forEach(el => observer.observe(el));

// Club Events Page Setup
let currentClub = "";
if (currentPage === "club_events.html") {
    const urlParams = new URLSearchParams(window.location.search);
    currentClub = urlParams.get("club") || "Unknown Club";
    document.getElementById("club-title").innerText = `${currentClub} Events`;
    document.getElementById("tech-event-title").innerText = `${currentClub} - Tech Event`;
    document.getElementById("non-tech-event-title").innerText = `${currentClub} - Non-Tech Event`;
    const techDesc = document.getElementById("tech-event-desc");
    const nonTechDesc = document.getElementById("non-tech-event-desc");
    if (techDesc && nonTechDesc) {
        techDesc.innerText = `Participate in the technical side of ${currentClub}!`;
        nonTechDesc.innerText = `Join the fun and creative side of ${currentClub}!`;
    }
}

// Registration Modal
function openRegisterModal(type) {
    const modal = document.getElementById("registerModal");
    const eventNameSpan = document.getElementById("event-name");
    if (!modal || !eventNameSpan) {
        console.error("Register modal elements not found");
        return;
    }
    modal.classList.add("show");
    eventNameSpan.innerText = `${currentClub} - ${type}`;
}

function closeRegisterModal() {
    const modal = document.getElementById("registerModal");
    if (modal) modal.classList.remove("show");
}

function submitRegistration() {
    let name = document.getElementById("name").value.trim();
    let rollno = document.getElementById("rollno").value.trim();
    let email = document.getElementById("email").value.trim();
    let eventName = document.getElementById("event-name").innerText;

    if (!name || !rollno || !email) {
        alert("Please fill in all fields!");
        return;
    }
    if (!/^\d{2}[A-Za-z]{2}\d{4}$/.test(rollno)) {
        alert("Invalid roll number format (e.g., 22CS1001)!");
        return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        alert("Invalid email format!");
        return;
    }

    let registeredStudents = JSON.parse(localStorage.getItem("registeredStudents")) || [];
    if (registeredStudents.some(student => student.rollno === rollno && student.event === eventName)) {
        alert("You are already registered for this event!");
        return;
    }

    registeredStudents.push({ name, rollno, email, event: eventName });
    localStorage.setItem("registeredStudents", JSON.stringify(registeredStudents));
    alert(`${name} (Roll No: ${rollno}) registered for ${eventName}! Confirmation sent to ${email}.`);
    closeRegisterModal();
}

// Countdown Timer (for index.html)
function updateCountdown() {
    const countdown = document.getElementById("countdown");
    if (!countdown) return;

    const eventDate = new Date("2025-03-15T00:00:00").getTime();
    const now = new Date().getTime();
    const timeLeft = eventDate - now;

    if (timeLeft > 0) {
        const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
        countdown.innerHTML = `${days}d ${hours}h ${minutes}m ${seconds}s until TechFest!`;
    } else {
        countdown.innerHTML = "TechFest is live!";
    }
}
if (document.getElementById("countdown")) {
    setInterval(updateCountdown, 1000);
    updateCountdown();
}

// Particle Background (for index.html)
if (document.getElementById("particles-js")) {
    particlesJS("particles-js", {
        particles: {
            number: { value: 80, density: { enable: true, value_area: 800 } },
            color: { value: "#ff9800" },
            shape: { type: "circle" },
            opacity: { value: 0.5, random: true },
            size: { value: 3, random: true },
            move: { speed: 6, direction: "none", random: true }
        },
        interactivity: {
            events: { onhover: { enable: true, mode: "repulse" }, onclick: { enable: true, mode: "push" } }
        }
    });
}

// Faculty Dashboard (for faculty_dashboard.html)
if (window.location.pathname.includes("faculty_dashboard.html")) {
    filterStudents();
}

function filterStudents() {
    let filter = document.getElementById("eventFilter").value;
    let studentList = document.getElementById("registered-students");
    let registeredStudents = JSON.parse(localStorage.getItem("registeredStudents")) || [];

    if (filter === "all") {
        studentList.innerHTML = registeredStudents.map(student => `<li>${student.rollno} - ${student.name} (${student.event})</li>`).join("");
        document.getElementById("event-title").innerText = "Registered Students";
    } else {
        let filtered = registeredStudents.filter(student => student.event === filter);
        studentList.innerHTML = filtered.length ? filtered.map(student => `<li>${student.rollno} - ${student.name}</li>`).join("") : "<li>No students registered for this event.</li>";
        document.getElementById("event-title").innerText = `Registered Students for ${filter}`;
    }
}

function clearAttendance() {
    localStorage.removeItem("registeredStudents");
    alert("Attendance cleared!");
    location.reload();
}

function exportAttendance() {
    let registeredStudents = JSON.parse(localStorage.getItem("registeredStudents")) || [];
    let csv = "Roll No,Name,Event,Email\n" + registeredStudents.map(s => `${s.rollno},${s.name},${s.event},${s.email}`).join("\n");
    let blob = new Blob([csv], { type: "text/csv" });
    let url = URL.createObjectURL(blob);
    let a = document.createElement("a");
    a.href = url;
    a.download = "attendance.csv";
    a.click();
}

// 💖 Toggle Input Fields Based on Role (For Login Page)
function toggleFields() {
    const role = document.getElementById("role").value;
    const usernameField = document.getElementById("username");
    const facultyIdField = document.getElementById("facultyId");
    const passwordField = document.getElementById("password");

    if (role === "student") {
        usernameField.style.display = "block";
        facultyIdField.style.display = "none";
        passwordField.style.display = "block";
    } else if (role === "faculty") {
        usernameField.style.display = "none";
        facultyIdField.style.display = "block";
        passwordField.style.display = "block";
    } else {
        usernameField.style.display = "none";
        facultyIdField.style.display = "none";
        passwordField.style.display = "none";
    }
}

// 💖 Login Function (For Login Page)
function loginUser() {
    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;
    const facultyId = document.getElementById("facultyId").value;
    const password = document.getElementById("password").value;

    if (role === "") {
        alert("Please select a role!");
        return;
    }

    if (role === "student" && (username === "" || password === "")) {
        alert("Please enter username and password!");
        return;
    }

    if (role === "faculty" && (facultyId === "" || password === "")) {
        alert("Please enter Faculty ID and password!");
        return;
    }

    // Store role in localStorage for dashboard access
    localStorage.setItem("role", role);

    if (role === "student") {
        alert("Student Login Successful! 🚀");
        window.location.href = "events.html"; // Redirect to Events Page
    } else if (role === "faculty") {
        alert("Faculty Login Successful! 🌟");
        window.location.href = "faculty_dashboard.html"; // Redirect to Faculty Dashboard
    }
}
// Ensure this is in your script.js
function toggleFields() {
    const role = document.getElementById("role").value;
    const usernameField = document.getElementById("username");
    const facultyIdField = document.getElementById("facultyId");
    const passwordField = document.getElementById("password");

    // Reset all fields to hidden first
    usernameField.style.display = "none";
    facultyIdField.style.display = "none";
    passwordField.style.display = "none";

    // Show relevant fields based on role
    if (role === "student") {
        usernameField.style.display = "block";
        passwordField.style.display = "block";
    } else if (role === "faculty") {
        facultyIdField.style.display = "block";
        passwordField.style.display = "block";
    }
}

function loginUser() {
    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;
    const facultyId = document.getElementById("facultyId").value;
    const password = document.getElementById("password").value;

    if (role === "") {
        alert("Please select a role!");
        return;
    }

    if (role === "student" && (username === "" || password === "")) {
        alert("Please enter username and password!");
        return;
    }

    if (role === "faculty" && (facultyId === "" || password === "")) {
        alert("Please enter Faculty ID and password!");
        return;
    }

    localStorage.setItem("role", role);

    if (role === "student") {
        alert("Student Login Successful! 🚀");
        window.location.href = "events.html";
    } else if (role === "faculty") {
        alert("Faculty Login Successful! 🌟");
        window.location.href = "faculty_dashboard.html";
    }
}
// Ensure this is in your script.js
function showCategory(category) {
    if (category === 'tech') {
        document.getElementById("tech-sub-events").classList.remove("hidden");
        document.getElementById("non-tech-sub-events").classList.add("hidden");
    } else {
        document.getElementById("tech-sub-events").classList.add("hidden");
        document.getElementById("non-tech-sub-events").classList.remove("hidden");
    }
    document.querySelectorAll(".category-btn").forEach(btn => btn.classList.remove("active"));
    document.querySelector(`[onclick="showCategory('${category}')"]`).classList.add("active");
}